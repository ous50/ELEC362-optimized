#include "drawingsaver.h"
#include "ui_drawingsaver.h"

DrawingSaver::DrawingSaver(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::DrawingSaver)
{ // This function is called when the user starts the application
    ui->setupUi(this);

    setCentralWidget(ui->graphicsView); // Setting the layout of the application
    ui->graphicsView->setScene(scene); // Connecting the scene to the view
}

DrawingSaver::~DrawingSaver()
{ // this function is called whn the user closes the application
    delete ui;
}


void DrawingSaver::on_actionAdd_rectangle_triggered()
{ // This action is triggered any time the user wants to add a rectange to the drawing

    QRect rect(10,10,100,100); // Defining a rectangle object
    QGraphicsRectItem* rect_item=scene->addRect(rect); // Adding the object to the scene and casting it into a QGraphicsItem object
    rect_item->setFlag(QGraphicsItem::ItemIsMovable); // enabling move by mouse featue for the rectangle items on the scene

}


void DrawingSaver::on_actionSave_triggered()
{ // This function is called when the user wants to save the drawing

    QString FileName=QFileDialog::getSaveFileName(this,"save file"); // Asking the user what the name of the file they want to save and where

    QFile file(FileName); // Creating a file with that name

    file.open(QIODevice::WriteOnly); // Openning the file for writing

    QDataStream stream(&file); // Creeating a datastream to save the data making the drawing

    QList<QGraphicsItem*> allItems_list=scene->items(Qt::AscendingOrder); // A function returning a list of all items in the scene

    int size=allItems_list.size();


    stream <<  size;// 1. Recording the number of items in the list

    for (int i=0;i<size;i++) { // For every element do the following:

        stream << allItems_list[i]->pos(); // 2. Save the poisition of the item
        stream << allItems_list[i]->boundingRect().width(); // 3. Save the width of the item
        stream << allItems_list[i]->boundingRect().height(); // 4. Save the hight of the item
        stream << allItems_list[i]->flags(); // 5. Save the flags set on

    }

    file.close();

}


void DrawingSaver::on_actionLoad_triggered()
{ // This function is called when the user want to load a drawing saved earlier



    QString FileName=QFileDialog::getOpenFileName(this,"Load file"); // Asking the user what file they want to load and where it is

    QFile file(FileName); // Creating a "local" file with that name to handle reading

    file.open(QIODevice::ReadOnly);



    // Openning the file for reading

    QDataStream stream(&file); // Creating a datastream to recover the data making the drawing



    // here we follow the same steps in saveing but in reverse order (first element in -first element out)

    int list_size; // The number of items to be recovered
    QPointF pos; // Position of the item
    qreal width; // Width of the enclosing rectangle of the item
    qreal height; // Height of the enclosing rectangle of the item
    QGraphicsItem::GraphicsItemFlags flags; // Flags of the items that are set on


    stream >> list_size; // 1. Reading the number of items in the list

    for (int i=0;i<list_size;i++) { // For every element do the following:

      stream >> pos; // 2. Read the poisition of the item
      stream >> width; // 3. Read the width of the item
      stream >> height; // 4. Save the hight of the item
      stream >> flags; // 5. read the flags set on
      //6. Add the item to the scene one at a time:
      scene->addRect(pos.x(),pos.y(),width,height);//->setFlags(flags);

       }

    file.close();

}

