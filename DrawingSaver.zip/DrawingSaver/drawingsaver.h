#ifndef DRAWINGSAVER_H
#define DRAWINGSAVER_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QRect>
#include <QGraphicsRectItem>
#include <QFile>
#include <QDataStream>
#include <QFileDialog>
#include <QList>

QT_BEGIN_NAMESPACE
namespace Ui { class DrawingSaver; }
QT_END_NAMESPACE

class DrawingSaver : public QMainWindow
{
    Q_OBJECT

public:
    DrawingSaver(QWidget *parent = nullptr);
    ~DrawingSaver();

private slots:
    void on_actionAdd_rectangle_triggered();

    void on_actionSave_triggered();

    void on_actionLoad_triggered();

private:
    Ui::DrawingSaver *ui;

    QGraphicsScene *scene=new QGraphicsScene();
};
#endif // DRAWINGSAVER_H
