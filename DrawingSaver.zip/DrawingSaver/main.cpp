#include "drawingsaver.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    DrawingSaver w;
    w.show();
    return a.exec();
}
