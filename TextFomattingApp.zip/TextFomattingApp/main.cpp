#include "textformatingapp.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TextFormatingApp w;
    w.show();
    return a.exec();
}
