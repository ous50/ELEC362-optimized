#ifndef CHANGEFONTDIALOG_H
#define CHANGEFONTDIALOG_H

#include <QDialog>

namespace Ui {
class ChangeFontDialog;
}

class ChangeFontDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChangeFontDialog(QWidget *parent = nullptr);
    ~ChangeFontDialog();


    int UserInputFont=10; // Defualt font

private slots:
    void on_ChangeFontDialog_accepted();

private:
    Ui::ChangeFontDialog *ui;


};

#endif // CHANGEFONTDIALOG_H
