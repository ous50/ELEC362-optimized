#ifndef TEXTFORMATINGAPP_H
#define TEXTFORMATINGAPP_H

#include <QMainWindow>
#include <QContextMenuEvent>
#include <QMenu>
#include <QFont>
#include <QDebug>
#include "changefontdialog.h"

QT_BEGIN_NAMESPACE
namespace Ui { class TextFormatingApp; }
QT_END_NAMESPACE

class TextFormatingApp : public QMainWindow
{
    Q_OBJECT

public:
    TextFormatingApp(QWidget *parent = nullptr);
    ~TextFormatingApp();


    void contextMenuEvent(QContextMenuEvent *event); // Notice that it is italic as this function overrides a virtual function
    void ConstructContextMenu(); // We ceated this function to construct the menu (it is a normal function like we did in Lecture 7)



private slots:
    void on_actionChange_Font_triggered();

private:
    Ui::TextFormatingApp *ui;
    QMenu *p_ContextMenu=new QMenu(); // The context menu (appears when the user right-clicks somehwere on the app)
    QMenu *p_SecondaryContextMenu=new QMenu(); // A secondary menu that can be accessed through context menu


    // Setting an object to control the properties of the font in the app
    // Deafult font is Arial, with font size of 50, and non-italic (false)
    QFont *p_TextFont=new QFont("Arial",10,10,false);



    // Constructing a new window to ask the user to input the new font
    ChangeFontDialog *FontDlg=new ChangeFontDialog();


};
#endif // TEXTFORMATINGAPP_H
