#include "changefontdialog.h"
#include "ui_changefontdialog.h"

ChangeFontDialog::ChangeFontDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChangeFontDialog)
{ // This function is called when the dialog for changing font is initiated
    ui->setupUi(this);



}

ChangeFontDialog::~ChangeFontDialog()
{ // This function is called when the dialog for changing font is closed
    delete ui;
}

void ChangeFontDialog::on_ChangeFontDialog_accepted()
{ // This function is called when the user clicks OK on the font dialog

    UserInputFont=ui->input_font->value(); // Reads the value entered by the user

}

