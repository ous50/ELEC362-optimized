#include "textformatingapp.h"
#include "ui_textformatingapp.h"

TextFormatingApp::TextFormatingApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TextFormatingApp)
{// this function is called when the user starts the app
    ui->setupUi(this);

    // This sets the layout for the QMainWindow app, by setting the main wedget the user will be interacting with
    setCentralWidget(ui->main_textEdit);

    // It is a good idea to construct all menues in the constructor to make the application faster:
    ConstructContextMenu();


    // Setting the deafult font on the app:
    ui->main_textEdit->setFont(*p_TextFont);

}

TextFormatingApp::~TextFormatingApp()
{ // This function is called when the user closes the app
    delete ui;

    // Clean up (the order matters):

    delete p_ContextMenu;
    delete p_SecondaryContextMenu;
    delete p_TextFont;
    delete FontDlg;
}

void TextFormatingApp::contextMenuEvent(QContextMenuEvent *event)
{// This function is called when the user right-clickes anywhere on the textEdit widget

   // displayes the context menue at the point where the user clicks:
    p_ContextMenu->popup(event->globalPos());

}

void TextFormatingApp::ConstructContextMenu()
{ // This is a normal function called whenever its name appear somewhere in the code
  // It is used to construct the context menu in the app

    p_ContextMenu->addAction(ui->actionChange_Font);
    p_ContextMenu->addSeparator(); // Line sperating different entries in the menu
    p_ContextMenu->addAction("Do somehting else"); // A menu option that does nothing

    // Constructing the secondary menu
    p_SecondaryContextMenu->setTitle("Secondary menu"); // This is how the secondary menu appears in the context menu
    p_SecondaryContextMenu->addAction("do another thing"); // Adding an option that does nothing in the secondary menu

    // Making the secondary menu an option in the context menu
    p_ContextMenu->addMenu(p_SecondaryContextMenu);

}


void TextFormatingApp::on_actionChange_Font_triggered()
{ // This function is called whenever the user uses any way to change the font


   // Displays "Change Font dialog" when the user triggers change font action
   FontDlg->exec();

   // changes the font of the text based on te value the user input
   p_TextFont->setPointSize(FontDlg->UserInputFont);


   // Updating the font in the text edit after its size was changed
   ui->main_textEdit->setFont(*p_TextFont);


}

