#include "notesavingapp.h"
#include "ui_notesavingapp.h"

NoteSavingApp::NoteSavingApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::NoteSavingApp)
{ // Called when the user starts the application
    ui->setupUi(this);

    setCentralWidget(ui->text); // Setting the layout for the application
}

NoteSavingApp::~NoteSavingApp()
{ // Called when the user closes the application
    delete ui;
}


void NoteSavingApp::on_actionLoad_triggered()
{ // Called when the user triggers Load action to load a file

    QString fileName=QFileDialog::getOpenFileName(this,"Load a file"); // Asking the user what file they want to load and where it is stored

    QFile loadFile(fileName); // Creating a new file with the file name given by the user

    loadFile.open(QIODevice::ReadOnly); // Openning the file for reading

    QTextStream input(&loadFile); // Defining the text stream to be "extracted" from the file


    QString read_text=input.readAll(); // finally doing the reading

    ui->text->setPlainText(read_text); // showing the read text to the user on the UI

    loadFile.close();


}


void NoteSavingApp::on_actionSave_triggered()
{ // Called when the user triggers Save action to save a file


    QString input_text=ui->text->toPlainText(); // Reading the text from the UI and storing it into a lcal variable

    QString fileName=QFileDialog::getSaveFileName(this,"Save a file"); // Asking the user what the file name will be and where it will be stored

    QFile savedFile(fileName); // Creating a new file with the file name given by the user

    savedFile.open(QIODevice::WriteOnly); // Openning the file for writing

    QTextStream output(&savedFile); // Defining the text stream to be "flushed" into the file
    // Note that the file's name is passed by reference because we want to write to that file rather than a copy of it!

    output << input_text; // finally doing the writing

    savedFile.close();



}

