#ifndef NOTESAVINGAPP_H
#define NOTESAVINGAPP_H

#include <QMainWindow>
#include <QFile>
#include <QFileDialog>
#include <QTextStream>

QT_BEGIN_NAMESPACE
namespace Ui { class NoteSavingApp; }
QT_END_NAMESPACE

class NoteSavingApp : public QMainWindow
{
    Q_OBJECT

public:
    NoteSavingApp(QWidget *parent = nullptr);
    ~NoteSavingApp();

private slots:
    void on_actionLoad_triggered();

    void on_actionSave_triggered();

private:
    Ui::NoteSavingApp *ui;
};
#endif // NOTESAVINGAPP_H
