#include "notesavingapp.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    NoteSavingApp w;
    w.show();
    return a.exec();
}
