#ifndef MOUSELOCATOR_H
#define MOUSELOCATOR_H

#include <QDialog>
#include <QMouseEvent>
#include <QPaintEvent>
#include <QPainter>

QT_BEGIN_NAMESPACE
namespace Ui { class MouseLocator; }
QT_END_NAMESPACE

class MouseLocator : public QDialog
{
    Q_OBJECT

public:
    MouseLocator(QWidget *parent = nullptr);
    ~MouseLocator();


    void mousePressEvent(QMouseEvent *event); // Notice that it is written in italic indicating that this function overrisdes a virtual one
    void paintEvent(QPaintEvent *event); // This event handler handles painintg on the widget based on user action

private:
    Ui::MouseLocator *ui;

    QColor colour=Qt::black; // the colour of the rectanlge to be displayed


};
#endif // MOUSELOCATOR_H
