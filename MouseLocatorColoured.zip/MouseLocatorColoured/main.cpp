#include "mouselocator.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MouseLocator w;
    w.show();
    return a.exec();
}
