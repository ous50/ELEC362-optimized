#include "mouselocator.h"
#include "ui_mouselocator.h"

MouseLocator::MouseLocator(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::MouseLocator)
{ // this function is called whn the user starts te app
    ui->setupUi(this);
}

MouseLocator::~MouseLocator()
{ // This function is called when the user closes the app
    delete ui;
}

void MouseLocator::mousePressEvent(QMouseEvent *event)
{ // This function is called whenever the user clicks on the MouseLocator app

    ui->x_lcdNumber->display(event->position().x()); // Displaying the x coordinato of the click

    ui->y_lcdNumber->display(event->position().y()); // Displaying the y coordinato of the click


     // In this switch-case statement we determine which mouse button has been clicked, then we assign a unique colour to every button

    switch(event->button()){ // The function "button" of event returns enumarator that has the type of the key pressed
    case Qt::RightButton: // Right button pressed
        colour=Qt::red;
        break;

    case Qt::LeftButton: // Left button pressed
        colour=Qt::blue;
        break;

    case Qt::MiddleButton: // Middle button pressed
        colour=Qt::yellow;
        break;

    deafult:
        break;
    }

  update(); // This function calls the paintEvent function: which causes the widget to be redrawn

}

void MouseLocator::paintEvent(QPaintEvent *)
{ // This function is called whenever there is a painitng event initiated by the function update()/repaint()
  // it is also called automatically by the constructor of the class it is in

    QPainter painter(this); // This line defines the opject painter (which is the object that will draw on the widget)
   /* the object painter needs a pointer to point to the widget it will be drawing on
    Since this code ir written in MouseLocator (the widget on which the painter will paint on)
    we need to point to the class from within it, the only way to do that is by using the "this" pointer */

    QBrush brush(colour); // Setting the brush of the painter

    painter.setBrush(brush); // Setting the colour of the brush to that chosed in mousePressEvent

    painter.drawRect(10,10,200,200); // drawing a rectangle using the brush , with a corcer of x = y = 10 pixels, and a width=height=200 pixels

}

