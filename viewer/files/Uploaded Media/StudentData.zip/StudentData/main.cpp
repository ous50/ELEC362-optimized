#include "studentdata.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    StudentData w;
    w.show();

    // In Qt the try-throw-catch is only used when the potential run-time error may cause the application to crash.
    // Error handling for user input mistakes can be done normally using "if" statements in combination with QMessageBox dialogs

    // Because crashing the programme means terminating the event loop, the try-throw-catch is most of the tie handled in the main function of the app
    int exit_code;

    try {

    exit_code=a.exec(); // This line might throw an exception

    }

    // This catches errors went the app tries to alocate more memory than available to it
    catch (const std::bad_alloc &) {


         return EXIT_FAILURE;


    }

    return exit_code;

}
