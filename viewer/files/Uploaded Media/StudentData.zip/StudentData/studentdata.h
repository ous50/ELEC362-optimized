#ifndef STUDENTDATA_H
#define STUDENTDATA_H

#include <QDialog>
#include <QMessageBox>


namespace Ui {
class StudentData;
}

class StudentData : public QDialog
{
    Q_OBJECT

public:
    explicit StudentData(QWidget *parent = nullptr);
    ~StudentData();

private slots:
    void on_pushButton_clicked();

private:
    Ui::StudentData *ui;
    QString *p_Student_Name=nullptr; // Student Name variable
    QString *p_Student_ID=nullptr;// Student ID varaible
};

#endif // STUDENTDATA_H
