#include "studentdata.h"
#include "ui_studentdata.h"

StudentData::StudentData(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StudentData)
{
    ui->setupUi(this);
}

StudentData::~StudentData()
{
    delete ui;
}

void StudentData::on_pushButton_clicked()
{


    // Reading the Student's name:
    p_Student_Name=new QString (ui->Student_Name->text());


    bool isValidStudentName=true; // Flag to determine if the input is valid student number

    // Verifying that the name is valid (you can use try-throw-catch here as normal in C++ but it is not recommended in Qt):
    for (auto it =p_Student_Name->begin(); it!=p_Student_Name->end();it++)
    {
        if (!it->isLetter()) isValidStudentName=false;  // Sets the flag variable to false if something other than a letter is encountered

    }

    if (!isValidStudentName)
    {
            QMessageBox invalid_studentName_error(QMessageBox::Critical,"Error","Invalid input for the student's name",QMessageBox::Ok,this); // Creates a message box
            invalid_studentName_error.exec(); // Shows the message box
            ui->Student_Name->clear(); // Clear the invalid name
    }


     //TODO: Read the Student's ID number and handle input error


}

// TODO: Add paintevent handler
