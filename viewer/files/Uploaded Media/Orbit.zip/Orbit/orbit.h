#ifndef ORBIT_H
#define ORBIT_H

#include <QDialog>
#include <QGraphicsScene>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <QTransform>
#include <QTimer>


QT_BEGIN_NAMESPACE
namespace Ui { class Orbit; }
QT_END_NAMESPACE

class Orbit : public QDialog
{
    Q_OBJECT

public:
    Orbit(QWidget *parent = nullptr);
    ~Orbit();

private slots:
    void on_Start_btn_clicked();

    void on_Stop_btn_clicked();

    void moveEarth(); // We made this slot up to capture the singal "timeout()" emitted by the Timer

private:
    Ui::Orbit *ui;

    // Drawing the items
    QGraphicsScene* scene=new QGraphicsScene(); // Defining the "canvas" where different visual elements will be added

    // Defining the images as objects in the code
    QPixmap* sun=new QPixmap("://sun.png");
    QPixmap* earth=new QPixmap("://earth.png");

    // Converting image objects into graphics item objects compatable with the graphics view framework:
    QGraphicsPixmapItem*  sun_item=new  QGraphicsPixmapItem(*sun);
    QGraphicsPixmapItem*  earth_item=new  QGraphicsPixmapItem(*earth);

    // Definig an object to allow changing the size and the scale of all objects
    QTransform* transform=new QTransform();

    // Defining a timer to control the motion of the earth around the sun:
    QTimer * Timer=new QTimer();


};
#endif // ORBIT_H
