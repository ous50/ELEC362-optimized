#include "orbit.h"
#include "ui_orbit.h"

Orbit::Orbit(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Orbit)
{ // This function is called when the user starts the app
    ui->setupUi(this);


    scene->setBackgroundBrush(Qt::black); // Setting the background colour of the scene to that of space
    ui->graphicsView->setScene(scene); // Connecting the scene to the view


    // Introducing the sun and earth ot the scene
    scene->addItem(sun_item);
    scene->addItem(earth_item);

    // Put the centre of the sun at the centre of the scene:
    qreal x_offset=0.5*sun_item->boundingRect().width();
    qreal y_offset=0.5*sun_item->boundingRect().height();
    sun_item->setOffset(-x_offset,-y_offset);


    // Put the centre of the earth far away from the sun:
     x_offset=0.5*earth_item->boundingRect().width();
     y_offset=0.5*earth_item->boundingRect().height();
     earth_item->setOffset(8000-x_offset,-y_offset);// the 8000 is a factor to represent the distance between earth adn the sun
     earth_item->setTransform(transform->scale(0.2,0.2)); // making the earth's image smaller than that of the sun


    // scale the view so that the sun and earth fit in the same view:
    ui->graphicsView->scale(0.1,0.1);


    Timer->start(100); // The timer will emit a signal called "timeout()" every 100 ms, we need a slot to capture the signal



}

Orbit::~Orbit()
{ // this function is called when the user closes the app
    delete ui;

    // don't forger to clean up (the order of deletion matters!!)

    delete Timer;
    delete transform;
    delete sun_item;
    delete earth_item;
    delete sun;
    delete earth;
    delete scene;

    // Scene is deleted last because all the item objects live on it

}


void Orbit::on_Start_btn_clicked()
{ // This function is called when the user clicks on the Start button (starts the animation)
    connect(Timer,SIGNAL(timeout()),this,SLOT(moveEarth()));

    // Note here that the receving object of the signal is the class Orbit, we need a pointer to point to it to do the connection
    // Since this code is written inside the class Orbit, the only way we can point to a class from its inside is by using "this" pointer
}


void Orbit::on_Stop_btn_clicked()
{ // This function is called when the user clicks on disconnect (stops the animation)
    disconnect(Timer,SIGNAL(timeout()),this,SLOT(moveEarth()));

    // Note here that the receving object of the signal is the class Orbit, we need a pointer to point to it to do the connection
    // Since this code is written inside the class Orbit, the only way we can point to a class from its inside is by using "this" pointer
}

void Orbit::moveEarth()
{ // This is a made-up slot function which will be executed whever the signal "timeout()" is emitted by the timer

    earth_item->setTransform(transform->rotate(15,Qt::ZAxis)); // rotates the earth around the centre of the scene by 15 degrees

}

