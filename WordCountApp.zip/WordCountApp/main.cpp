#include "wordcountapp.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    WordCountApp w;
    w.show();
    return a.exec();
}
