#include "wordcountapp.h"
#include "ui_wordcountapp.h"

WordCountApp::WordCountApp(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::WordCountApp)
{  // This function is only called when the app starts as it is the constructor
    ui->setupUi(this);
}

WordCountApp::~WordCountApp()
{ // This function is only called when the app is closed as it is the destructor
    delete ui;

    // Don't forget the cleanup

    delete p_WordToBeCounted;
    delete p_Paragraph;

}


void WordCountApp::on_Count_btn_clicked()
{  // This function is called when the user clickes on the push button

    p_WordToBeCounted=new QString (ui->input_lineEdit->text()); // reads the word to be counted from the user interface


    p_Paragraph=new QString(ui->input_paragraph->toPlainText()); // reads the paragraph text

    CountNum=p_Paragraph->count(*p_WordToBeCounted); // Counting the occurances of "WordToBeCounted" into "Paragraph"


    QString TextCountNumber; // This is a dummy variable needed to convert the number to string, it won't be needed outside this function (no pointers needed)

    TextCountNumber.setNum(CountNum); // converting the count number into text to be diaplyed into lineEdit object

    ui->output_lineEdit->insert(TextCountNumber); // Displaying the count number to the user

}

