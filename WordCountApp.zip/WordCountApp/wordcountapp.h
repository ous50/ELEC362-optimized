#ifndef WORDCOUNTAPP_H
#define WORDCOUNTAPP_H

#include <QDialog>
#include <QString>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class WordCountApp; }
QT_END_NAMESPACE

class WordCountApp : public QDialog
{
    Q_OBJECT

public:
    WordCountApp(QWidget *parent = nullptr);
    ~WordCountApp();

private slots:
    void on_Count_btn_clicked();

private:
    Ui::WordCountApp *ui;
    QString *p_WordToBeCounted=nullptr; // Pointer to store the word to be counted
    QString *p_Paragraph=nullptr; // Pointer to the typed paragraph


    // Output variables:
    int CountNum=0; // Variable to strore the number of counts



};
#endif // WORDCOUNTAPP_H
